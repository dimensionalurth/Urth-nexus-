"""
Pydantic schemas — request/response shapes for the MVP endpoints.
Kept separate from models.py so DB structure and API contract can evolve
independently (e.g. hiding hashed_password from every User response).
"""
from datetime import datetime
from typing import Optional, Any
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field

from app.models import UserRole, AlertSeverity, AlertStatus, LayerType


# ----------------------------------------------------------------- Auth ----
class UserCreate(BaseModel):
    email: EmailStr
    full_name: str
    password: str = Field(min_length=8)
    organization_id: Optional[UUID] = None
    role: UserRole = UserRole.viewer


class UserOut(BaseModel):
    id: UUID
    email: EmailStr
    full_name: str
    role: UserRole
    organization_id: Optional[UUID]

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


# -------------------------------------------------------------- Projects --
class ProjectCreate(BaseModel):
    organization_id: UUID
    name: str
    aoi_geojson: Optional[dict] = None  # GeoJSON polygon for the area of interest


class ProjectOut(BaseModel):
    id: UUID
    organization_id: UUID
    name: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


# -------------------------------------------------------------- Imagery ---
class SatelliteImageOut(BaseModel):
    id: UUID
    source: str
    capture_date: datetime
    storage_url: str
    cloud_cover_pct: Optional[float]

    class Config:
        from_attributes = True


# ------------------------------------------------------------- EO Layers --
class EOLayerOut(BaseModel):
    id: UUID
    image_id: UUID
    layer_type: LayerType
    raster_url: str
    computed_at: datetime

    class Config:
        from_attributes = True


class DetectChangeRequest(BaseModel):
    project_id: UUID
    layer_type: LayerType
    before_image_id: UUID
    after_image_id: UUID


# ------------------------------------------------------------------ Alerts-
class AlertOut(BaseModel):
    id: UUID
    project_id: UUID
    entity_type: str
    severity: AlertSeverity
    status: AlertStatus
    message: str
    triggered_at: datetime

    class Config:
        from_attributes = True


class AlertCreate(BaseModel):
    project_id: UUID
    entity_type: str
    entity_id: Optional[UUID] = None
    severity: AlertSeverity = AlertSeverity.info
    message: str


# ----------------------------------------------------------------- Reports-
class ReportGenerateRequest(BaseModel):
    project_id: UUID
    period_start: datetime
    period_end: datetime


class ReportOut(BaseModel):
    id: UUID
    project_id: UUID
    period_start: datetime
    period_end: datetime
    file_url: Optional[str]
    generated_at: datetime

    class Config:
        from_attributes = True


# ------------------------------------------------------------------ Layers-
class GeoJSONFeatureCollection(BaseModel):
    type: str = "FeatureCollection"
    features: list[dict[str, Any]]
