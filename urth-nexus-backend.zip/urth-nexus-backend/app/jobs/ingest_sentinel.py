"""
Scheduled Sentinel-2 ingestion job — Phase 1 of the build sequencing plan.

For every active Project with an AOI defined, searches CDSE for new
Sentinel-2 L2A scenes since the last ingested image for that project,
downloads them, uploads to Azure Blob, and writes a SatelliteImage row.

Run manually:
    python -m app.jobs.ingest_sentinel

Run on a schedule: see the cron / Azure Function notes in the README.
This is intentionally a plain script, not baked into the FastAPI process —
ingestion is I/O-heavy and slow (large downloads), and running it inside
the API's event loop would block request handling. Keep it external.
"""
import sys
import uuid
from datetime import datetime, timedelta

from geoalchemy2.shape import to_shape
from shapely.geometry import mapping

from app.database import SessionLocal
from app.models import Project, SatelliteImage, ProjectStatus
from app.config import settings
from app.services.copernicus_client import (
    get_access_token,
    search_sentinel2,
    download_product,
    CopernicusAuthError,
)

try:
    from app.services.storage import upload_bytes_to_blob
except ImportError:  # pragma: no cover
    upload_bytes_to_blob = None

DEFAULT_LOOKBACK_DAYS = 10  # Sentinel-2 revisit time over the same tile
MAX_CLOUD_COVER_PCT = 30.0


def _project_bbox_wkt(project: Project) -> str | None:
    """Converts a Project's aoi_geom to a WKT POLYGON for the CDSE search filter."""
    if project.aoi_geom is None:
        return None
    shape = to_shape(project.aoi_geom)
    minx, miny, maxx, maxy = shape.bounds
    return (
        f"POLYGON(({minx} {miny}, {maxx} {miny}, {maxx} {maxy}, {minx} {maxy}, {minx} {miny}))"
    )


def _already_ingested(db, project_id, product_id: str) -> bool:
    """Uses storage_url (which embeds the CDSE product id) to avoid re-downloading
    a scene that's already in the database for this project."""
    existing = (
        db.query(SatelliteImage)
        .filter(SatelliteImage.storage_url.contains(product_id))
        .first()
    )
    return existing is not None


def ingest_for_project(db, project: Project, access_token: str) -> int:
    bbox_wkt = _project_bbox_wkt(project)
    if not bbox_wkt:
        print(f"  [skip] Project '{project.name}' has no AOI defined")
        return 0

    date_to = datetime.utcnow()
    date_from = date_to - timedelta(days=DEFAULT_LOOKBACK_DAYS)

    results = search_sentinel2(
        bbox_wkt_polygon=bbox_wkt,
        date_from=date_from,
        date_to=date_to,
        max_cloud_cover_pct=MAX_CLOUD_COVER_PCT,
    )

    ingested = 0
    for scene in results:
        if _already_ingested(db, project.id, scene["id"]):
            continue

        print(f"  Downloading {scene['name']} ({scene['content_date']})...")
        try:
            raw_bytes = download_product(scene["id"], access_token)
        except Exception as e:
            print(f"  [error] download failed for {scene['id']}: {e}")
            continue

        blob_name = f"sentinel-2/{project.id}/{scene['id']}.zip"
        if upload_bytes_to_blob and settings.AZURE_STORAGE_CONNECTION_STRING:
            storage_url = upload_bytes_to_blob(
                raw_bytes, blob_name, container=settings.AZURE_CONTAINER_IMAGERY
            )
        else:
            # Local dev fallback — same pattern used by eo_processing / report_builder
            import os
            local_dir = "/tmp/urth-nexus-imagery"
            os.makedirs(local_dir, exist_ok=True)
            local_path = os.path.join(local_dir, f"{scene['id']}.zip")
            with open(local_path, "wb") as f:
                f.write(raw_bytes)
            storage_url = f"local-dev://{local_path}"

        footprint = scene.get("footprint_geojson")
        image = SatelliteImage(
            source="sentinel-2",
            capture_date=datetime.fromisoformat(scene["content_date"].replace("Z", "+00:00")),
            footprint_geom=f"SRID=4326;{bbox_wkt}",  # bbox as a stand-in until full footprint parsing is added
            storage_url=f"{storage_url}#{scene['id']}",  # embed product id for dedup checks above
            cloud_cover_pct=None,  # available in scene attributes; parse out if needed downstream
        )
        db.add(image)
        db.commit()
        ingested += 1
        print(f"  ✓ Ingested {scene['name']}")

    return ingested


def main():
    db = SessionLocal()
    try:
        access_token = get_access_token()
    except CopernicusAuthError as e:
        print(f"[fatal] {e}")
        sys.exit(1)

    projects = db.query(Project).filter(Project.status == ProjectStatus.active).all()
    if not projects:
        print("No active projects with AOIs — nothing to ingest.")
        return

    total = 0
    for project in projects:
        print(f"Project: {project.name}")
        total += ingest_for_project(db, project, access_token)

    print(f"\nDone. {total} new scene(s) ingested across {len(projects)} project(s).")
    db.close()


if __name__ == "__main__":
    main()
