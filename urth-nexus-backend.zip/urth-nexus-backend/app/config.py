"""
Central configuration, loaded from environment variables / .env.
Kept as one settings object so every module reads config the same way.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- Database (PostgreSQL + PostGIS) ---
    DATABASE_URL: str = "postgresql://urth:urth@localhost:5432/urth_nexus"

    # --- Auth ---
    JWT_SECRET: str = "dev-secret-change-me"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440

    # --- Azure Blob Storage (imagery + generated reports) ---
    AZURE_STORAGE_CONNECTION_STRING: str = ""
    AZURE_CONTAINER_IMAGERY: str = "satellite-imagery"
    AZURE_CONTAINER_REPORTS: str = "reports"

    # --- Satellite data sources ---
    # Copernicus Data Space Ecosystem authenticates via a Keycloak password
    # grant against your own free account — there is no separate client
    # secret to request. Register at https://dataspace.copernicus.eu
    COPERNICUS_USERNAME: str = ""
    COPERNICUS_PASSWORD: str = ""
    COPERNICUS_AOI_BUFFER_DEG: float = 0.05  # ~5km, widens a point AOI into a search box

    # --- Weather ---
    SAWS_API_KEY: str = ""  # left blank until a SAWS data-sharing agreement is in place
    OPEN_METEO_BASE_URL: str = "https://api.open-meteo.com/v1/forecast"

    # --- App ---
    ENVIRONMENT: str = "development"
    CORS_ORIGINS: str = "http://localhost:3000,http://localhost:8080"

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


settings = Settings()
