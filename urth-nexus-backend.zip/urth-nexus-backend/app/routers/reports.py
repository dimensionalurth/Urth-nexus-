"""
MVP capability 5 — Produce downloadable reports.

Generates a real PDF (reportlab) summarising alerts and EO layers for a
project over a given period, stores it in Azure Blob (or locally in dev),
and records it against the Reports table.
"""
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse, StreamingResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Project, Report, Alert
from app.schemas import ReportGenerateRequest, ReportOut
from app.deps import get_current_user
from app.services.report_builder import build_report_pdf

router = APIRouter(prefix="/api/reports", tags=["reports"])


@router.post("/generate", response_model=ReportOut, status_code=201)
def generate_report(
    payload: ReportGenerateRequest,
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    project = db.query(Project).get(payload.project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    alerts = (
        db.query(Alert)
        .filter(
            Alert.project_id == project.id,
            Alert.triggered_at >= payload.period_start,
            Alert.triggered_at <= payload.period_end,
        )
        .order_by(Alert.triggered_at.desc())
        .all()
    )

    file_url = build_report_pdf(
        project=project,
        alerts=alerts,
        period_start=payload.period_start,
        period_end=payload.period_end,
    )

    report = Report(
        project_id=project.id,
        period_start=payload.period_start,
        period_end=payload.period_end,
        file_url=file_url,
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report


@router.get("/{report_id}", response_model=ReportOut)
def get_report(report_id: str, db: Session = Depends(get_db), _user=Depends(get_current_user)):
    report = db.query(Report).get(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report


@router.get("/{report_id}/download")
def download_report(report_id: str, db: Session = Depends(get_db), _user=Depends(get_current_user)):
    report = db.query(Report).get(report_id)
    if not report or not report.file_url:
        raise HTTPException(status_code=404, detail="Report not found or not yet generated")

    if report.file_url.startswith("local-dev://"):
        local_path = report.file_url.replace("local-dev://", "")
        return FileResponse(local_path, media_type="application/pdf", filename=f"report-{report_id}.pdf")

    # Production: redirect-style — Azure Blob URL is already directly downloadable
    # (or proxy it through here if the container is private).
    from fastapi.responses import RedirectResponse
    return RedirectResponse(report.file_url)
