"""
MVP capability 4 — Generate AI-powered alerts.

Alerts are created two ways: (1) automatically, when an EO layer's values
cross a threshold (see check_thresholds in services/alerting.py, called
after every /api/eo/detect-change), and (2) manually, via this router,
for field-reported issues. Both land in the same Alerts table so the
Flutter feed doesn't need to distinguish their origin.
"""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Alert, AlertStatus
from app.schemas import AlertOut, AlertCreate
from app.deps import get_current_user

router = APIRouter(prefix="/api/alerts", tags=["alerts"])


@router.get("", response_model=list[AlertOut])
def list_alerts(
    project_id: Optional[str] = None,
    status: Optional[AlertStatus] = None,
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    query = db.query(Alert)
    if project_id:
        query = query.filter(Alert.project_id == project_id)
    if status:
        query = query.filter(Alert.status == status)
    return query.order_by(Alert.triggered_at.desc()).limit(200).all()


@router.post("", response_model=AlertOut, status_code=201)
def create_alert(
    payload: AlertCreate,
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    alert = Alert(**payload.model_dump())
    db.add(alert)
    db.commit()
    db.refresh(alert)
    return alert


@router.patch("/{alert_id}/acknowledge", response_model=AlertOut)
def acknowledge_alert(
    alert_id: str,
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    alert = db.query(Alert).get(alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    alert.status = AlertStatus.acknowledged
    db.commit()
    db.refresh(alert)
    return alert


@router.patch("/{alert_id}/resolve", response_model=AlertOut)
def resolve_alert(
    alert_id: str,
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    from datetime import datetime

    alert = db.query(Alert).get(alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    alert.status = AlertStatus.resolved
    alert.resolved_at = datetime.utcnow()
    db.commit()
    db.refresh(alert)
    return alert
