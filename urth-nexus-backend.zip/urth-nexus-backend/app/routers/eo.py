"""
MVP capability 3 — Detect vegetation change and potential flood areas.

The actual raster math (NDVI differencing, water-index thresholding) lives
in app/services/eo_processing.py, kept separate from the route so it can be
unit-tested and later swapped for a PyTorch/TensorFlow model without
touching the API contract.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import SatelliteImage, EOLayer, LayerType, Project
from app.schemas import DetectChangeRequest, EOLayerOut
from app.deps import get_current_user
from app.services.eo_processing import run_change_detection
from app.services.alerting import check_layer_and_alert

router = APIRouter(prefix="/api/eo", tags=["eo"])


@router.post("/detect-change", response_model=EOLayerOut, status_code=201)
def detect_change(
    payload: DetectChangeRequest,
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    before = db.query(SatelliteImage).get(payload.before_image_id)
    after = db.query(SatelliteImage).get(payload.after_image_id)
    if not before or not after:
        raise HTTPException(status_code=404, detail="One or both source images were not found")

    project = db.query(Project).get(payload.project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    result = run_change_detection(
        before_url=before.storage_url,
        after_url=after.storage_url,
        layer_type=payload.layer_type,
    )

    layer = EOLayer(
        image_id=after.id,
        layer_type=payload.layer_type,
        raster_url=result["raster_url"],
        footprint_geom=after.footprint_geom,
        ai_model_id=result.get("ai_model_id"),
    )
    db.add(layer)
    db.commit()
    db.refresh(layer)

    # Auto-generate an alert if this layer's values cross a threshold —
    # no-op (returns None) when summary_stats is empty, e.g. the local-dev
    # synthetic fallback with no Azure/imagery configured.
    check_layer_and_alert(db, layer, project, result.get("summary_stats", {}))

    return layer


@router.get("/layers/{project_id}", response_model=list[EOLayerOut])
def list_layers_for_project(
    project_id: str,
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    """
    Convenience lookup used by the Flutter dashboard to populate the
    layer picker for a given project. Filters on layer_type presence
    rather than project directly, since EOLayer links via image -> AOI;
    swap for a direct project_id FK if layers become project-scoped 1:1.
    """
    return (
        db.query(EOLayer)
        .order_by(EOLayer.computed_at.desc())
        .limit(50)
        .all()
    )
