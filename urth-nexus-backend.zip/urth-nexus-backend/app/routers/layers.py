"""
MVP capability 2 — Show municipal boundaries and infrastructure layers.

Both endpoints return GeoJSON FeatureCollections so MapLibre GL can add
them as a source directly with no client-side transformation.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from geoalchemy2.shape import to_shape
from shapely.geometry import mapping

from app.database import get_db
from app.models import Municipality, Infrastructure
from app.deps import get_current_user

router = APIRouter(prefix="/api/layers", tags=["layers"])


def _to_feature_collection(rows, properties_fn):
    features = []
    for row in rows:
        geom = to_shape(row.geom if hasattr(row, "geom") else row.boundary_geom)
        features.append({
            "type": "Feature",
            "geometry": mapping(geom),
            "properties": properties_fn(row),
        })
    return {"type": "FeatureCollection", "features": features}


@router.get("/municipalities")
def get_municipalities(db: Session = Depends(get_db), _user=Depends(get_current_user)):
    rows = db.query(Municipality).all()
    return _to_feature_collection(
        rows,
        lambda r: {"id": str(r.id), "name": r.name, "ward_count": r.ward_count, "province": r.province},
    )


@router.get("/infrastructure")
def get_infrastructure(db: Session = Depends(get_db), _user=Depends(get_current_user)):
    rows = db.query(Infrastructure).all()
    return _to_feature_collection(
        rows,
        lambda r: {"id": str(r.id), "category": r.category, "condition_status": r.condition_status},
    )
