"""
MVP capability 1 — Display South African satellite imagery.

Imagery itself lives in Azure Blob Storage; this table + endpoint index
what's available for a given area and date range so the Flutter map can
request only what it needs.
"""
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from geoalchemy2.functions import ST_Intersects, ST_GeomFromGeoJSON
import json

from app.database import get_db
from app.models import SatelliteImage
from app.schemas import SatelliteImageOut
from app.deps import get_current_user

router = APIRouter(prefix="/api/imagery", tags=["imagery"])


@router.get("", response_model=list[SatelliteImageOut])
def list_imagery(
    aoi: Optional[str] = Query(
        None, description="GeoJSON polygon (as a string) for the area of interest"
    ),
    date_from: Optional[datetime] = Query(None),
    date_to: Optional[datetime] = Query(None),
    source: Optional[str] = Query(None, description="'sentinel-2' | 'landsat-8' | 'modis'"),
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    query = db.query(SatelliteImage)

    if aoi:
        try:
            geojson_dict = json.loads(aoi)
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="aoi must be valid GeoJSON")
        aoi_geom = ST_GeomFromGeoJSON(json.dumps(geojson_dict))
        query = query.filter(ST_Intersects(SatelliteImage.footprint_geom, aoi_geom))

    if date_from:
        query = query.filter(SatelliteImage.capture_date >= date_from)
    if date_to:
        query = query.filter(SatelliteImage.capture_date <= date_to)
    if source:
        query = query.filter(SatelliteImage.source == source)

    return query.order_by(SatelliteImage.capture_date.desc()).limit(100).all()
