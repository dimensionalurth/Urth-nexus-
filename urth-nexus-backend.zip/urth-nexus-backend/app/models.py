"""
Urth Nexus — core database models.

Every spatial column uses geoalchemy2.Geometry(geometry_type, srid=4326) so
all entity tables are queryable with the same PostGIS functions
(ST_Intersects, ST_DWithin, ST_Area, ...) regardless of what they represent.

13 tables, matching the MVP spec:
Users, Organizations, Projects, Satellite_Images, EO_Layers, AI_Models,
Alerts, Reports, Municipalities, Mines, Farms, Water_Bodies,
Infrastructure, Disaster_Events.
"""
import uuid
import enum
from datetime import datetime

from sqlalchemy import (
    Column, String, Integer, Float, DateTime, ForeignKey, Enum, Text, JSON
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from geoalchemy2 import Geometry

from app.database import Base


def uuid_pk():
    return Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)


# ---------------------------------------------------------------- enums ----
class UserRole(str, enum.Enum):
    admin = "admin"
    analyst = "analyst"
    field_operator = "field_operator"
    viewer = "viewer"


class AlertSeverity(str, enum.Enum):
    info = "info"
    warning = "warning"
    critical = "critical"


class AlertStatus(str, enum.Enum):
    active = "active"
    acknowledged = "acknowledged"
    resolved = "resolved"


class ProjectStatus(str, enum.Enum):
    active = "active"
    paused = "paused"
    completed = "completed"


class LayerType(str, enum.Enum):
    ndvi = "ndvi"
    ndvi_change = "ndvi_change"
    flood_extent = "flood_extent"
    burn_scar = "burn_scar"
    land_cover = "land_cover"


# --------------------------------------------------------------- Users -----
class User(Base):
    __tablename__ = "users"

    id = uuid_pk()
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=True)
    email = Column(String, unique=True, nullable=False, index=True)
    full_name = Column(String, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(Enum(UserRole), default=UserRole.viewer, nullable=False)
    is_active = Column(Integer, default=1)  # 1/0 — kept simple, no boolean surprises across drivers
    created_at = Column(DateTime, default=datetime.utcnow)

    organization = relationship("Organization", back_populates="users")


# --------------------------------------------------------- Organizations ---
class Organization(Base):
    __tablename__ = "organizations"

    id = uuid_pk()
    name = Column(String, nullable=False)
    type = Column(String, nullable=False)  # 'mine' | 'municipality' | 'agency' | 'farm' | 'other'
    region = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    users = relationship("User", back_populates="organization")
    projects = relationship("Project", back_populates="organization")


# --------------------------------------------------------------- Projects --
class Project(Base):
    __tablename__ = "projects"

    id = uuid_pk()
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    name = Column(String, nullable=False)
    aoi_geom = Column(Geometry(geometry_type="POLYGON", srid=4326), nullable=True)
    status = Column(Enum(ProjectStatus), default=ProjectStatus.active)
    created_at = Column(DateTime, default=datetime.utcnow)

    organization = relationship("Organization", back_populates="projects")
    alerts = relationship("Alert", back_populates="project")
    reports = relationship("Report", back_populates="project")


# ------------------------------------------------------- Satellite Images --
class SatelliteImage(Base):
    __tablename__ = "satellite_images"

    id = uuid_pk()
    source = Column(String, nullable=False)  # 'sentinel-2' | 'landsat-8' | 'modis'
    capture_date = Column(DateTime, nullable=False)
    footprint_geom = Column(Geometry(geometry_type="POLYGON", srid=4326), nullable=False)
    storage_url = Column(String, nullable=False)  # Azure Blob path
    cloud_cover_pct = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    eo_layers = relationship("EOLayer", back_populates="image")


# -------------------------------------------------------------- EO Layers --
class EOLayer(Base):
    __tablename__ = "eo_layers"

    id = uuid_pk()
    image_id = Column(UUID(as_uuid=True), ForeignKey("satellite_images.id"), nullable=False)
    layer_type = Column(Enum(LayerType), nullable=False)
    raster_url = Column(String, nullable=False)  # Azure Blob path to the derived GeoTIFF
    footprint_geom = Column(Geometry(geometry_type="POLYGON", srid=4326), nullable=True)
    computed_at = Column(DateTime, default=datetime.utcnow)
    ai_model_id = Column(UUID(as_uuid=True), ForeignKey("ai_models.id"), nullable=True)

    image = relationship("SatelliteImage", back_populates="eo_layers")
    ai_model = relationship("AIModel", back_populates="eo_layers")


# -------------------------------------------------------------- AI Models --
class AIModel(Base):
    __tablename__ = "ai_models"

    id = uuid_pk()
    name = Column(String, nullable=False)  # e.g. 'ndvi-change-threshold'
    task_type = Column(String, nullable=False)  # 'change_detection' | 'classification' | 'anomaly'
    version = Column(String, nullable=False)
    framework = Column(String, nullable=True)  # 'scikit-learn' | 'pytorch' | 'tensorflow'
    metrics_json = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    eo_layers = relationship("EOLayer", back_populates="ai_model")


# ------------------------------------------------------------------ Alerts -
class Alert(Base):
    __tablename__ = "alerts"

    id = uuid_pk()
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)
    entity_type = Column(String, nullable=False)  # 'Mines' | 'Farms' | 'Municipalities' | ...
    entity_id = Column(UUID(as_uuid=True), nullable=True)
    severity = Column(Enum(AlertSeverity), default=AlertSeverity.info)
    status = Column(Enum(AlertStatus), default=AlertStatus.active)
    message = Column(Text, nullable=False)
    triggered_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)

    project = relationship("Project", back_populates="alerts")


# ----------------------------------------------------------------- Reports -
class Report(Base):
    __tablename__ = "reports"

    id = uuid_pk()
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)
    period_start = Column(DateTime, nullable=False)
    period_end = Column(DateTime, nullable=False)
    file_url = Column(String, nullable=True)  # Azure Blob path once generated
    generated_at = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="reports")


# ---------------------------------------------------------- Municipalities -
class Municipality(Base):
    __tablename__ = "municipalities"

    id = uuid_pk()
    name = Column(String, nullable=False)
    boundary_geom = Column(Geometry(geometry_type="MULTIPOLYGON", srid=4326), nullable=False)
    ward_count = Column(Integer, nullable=True)
    province = Column(String, nullable=True)


# ------------------------------------------------------------------- Mines -
class Mine(Base):
    __tablename__ = "mines"

    id = uuid_pk()
    name = Column(String, nullable=False)
    operator = Column(String, nullable=True)
    lease_boundary_geom = Column(Geometry(geometry_type="POLYGON", srid=4326), nullable=False)
    commodity = Column(String, nullable=True)


# ------------------------------------------------------------------- Farms -
class Farm(Base):
    __tablename__ = "farms"

    id = uuid_pk()
    name = Column(String, nullable=False)
    owner_org_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=True)
    parcel_geom = Column(Geometry(geometry_type="POLYGON", srid=4326), nullable=False)
    crop_type = Column(String, nullable=True)


# ------------------------------------------------------------- Water Bodies-
class WaterBody(Base):
    __tablename__ = "water_bodies"

    id = uuid_pk()
    name = Column(String, nullable=False)
    type = Column(String, nullable=False)  # 'dam' | 'river' | 'borehole' | 'irrigation_scheme'
    geom = Column(Geometry(geometry_type="GEOMETRY", srid=4326), nullable=False)
    capacity_ml = Column(Float, nullable=True)  # megalitres, where applicable


# ----------------------------------------------------------- Infrastructure-
class Infrastructure(Base):
    __tablename__ = "infrastructure"

    id = uuid_pk()
    category = Column(String, nullable=False)  # 'road' | 'pipeline' | 'power_line' | 'building'
    geom = Column(Geometry(geometry_type="GEOMETRY", srid=4326), nullable=False)
    condition_status = Column(String, nullable=True)  # 'good' | 'fair' | 'poor' | 'unknown'


# ------------------------------------------------------------ Disaster Events
class DisasterEvent(Base):
    __tablename__ = "disaster_events"

    id = uuid_pk()
    event_type = Column(String, nullable=False)  # 'flood' | 'fire' | 'drought'
    affected_geom = Column(Geometry(geometry_type="GEOMETRY", srid=4326), nullable=False)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=True)
    severity = Column(Enum(AlertSeverity), default=AlertSeverity.warning)
