"""
EO processing service — where GDAL / Rasterio / GeoPandas actually run.

This is deliberately the one place in the codebase that touches raster
math, so the AI/GIS stack stays swappable without rippling through the API
layer. The functions below are real, runnable implementations for the MVP
baseline (NDVI differencing + a water-index threshold for flood extent);
the PyTorch/TensorFlow upgrade path is noted inline where it slots in.
"""
import uuid
from datetime import datetime
from typing import Optional

import numpy as np
import rasterio
from rasterio.io import MemoryFile

from app.models import LayerType
from app.config import settings

try:
    from app.services.storage import download_blob_to_memory, upload_bytes_to_blob
except ImportError:  # pragma: no cover — storage.py needs real Azure credentials to import cleanly
    download_blob_to_memory = None
    upload_bytes_to_blob = None


def _read_band(path_or_bytes, band_index: int = 1) -> np.ndarray:
    """Read a single band from a local path, URL, or in-memory GeoTIFF."""
    if isinstance(path_or_bytes, (bytes, bytearray)):
        with MemoryFile(path_or_bytes) as memfile:
            with memfile.open() as src:
                return src.read(band_index).astype("float32")
    with rasterio.open(path_or_bytes) as src:
        return src.read(band_index).astype("float32")


def compute_ndvi(nir: np.ndarray, red: np.ndarray) -> np.ndarray:
    """Standard NDVI = (NIR - Red) / (NIR + Red), safe against divide-by-zero."""
    denom = nir + red
    denom = np.where(denom == 0, 1e-6, denom)
    return (nir - red) / denom


def ndvi_change(ndvi_before: np.ndarray, ndvi_after: np.ndarray) -> np.ndarray:
    """Positive = greening, negative = vegetation loss. Simple differencing —
    swap for a trained change-detection CNN (PyTorch) once labelled data exists."""
    return ndvi_after - ndvi_before


def flood_extent_mask(green: np.ndarray, nir: np.ndarray, threshold: float = 0.0) -> np.ndarray:
    """NDWI (McFeeters) water index thresholded to a binary flood/water mask.
    NDWI = (Green - NIR) / (Green + NIR); values above `threshold` = water.
    Baseline for the MVP — the spec's scikit-learn/PyTorch upgrade replaces
    this fixed threshold with a learned classifier."""
    denom = green + nir
    denom = np.where(denom == 0, 1e-6, denom)
    ndwi = (green - nir) / denom
    return (ndwi > threshold).astype("uint8")


def run_change_detection(before_url: str, after_url: str, layer_type: LayerType) -> dict:
    """
    Orchestrates the actual raster processing for a single detect-change
    request. Returns the storage URL of the derived layer plus which
    AI_Models row (if any) produced it, ready to attach to an EOLayer row.

    NOTE: This function expects imagery already downloaded to Azure Blob
    (see the Copernicus ingestion job, not included here). In local dev
    without Azure configured, it falls back to a synthetic result so the
    endpoint is exercisable end-to-end without cloud credentials.
    """
    if download_blob_to_memory is None or not settings.AZURE_STORAGE_CONNECTION_STRING:
        return _synthetic_result(layer_type)

    before_bytes = download_blob_to_memory(before_url)
    after_bytes = download_blob_to_memory(after_url)

    if layer_type in (LayerType.ndvi, LayerType.ndvi_change):
        nir_b, red_b = _read_band(before_bytes, 4), _read_band(before_bytes, 3)
        nir_a, red_a = _read_band(after_bytes, 4), _read_band(after_bytes, 3)
        result_array = ndvi_change(compute_ndvi(nir_b, red_b), compute_ndvi(nir_a, red_a))
        summary_stats = {"mean_change": float(np.nanmean(result_array))}
    elif layer_type == LayerType.flood_extent:
        green_a, nir_a = _read_band(after_bytes, 2), _read_band(after_bytes, 4)
        result_array = flood_extent_mask(green_a, nir_a)
        summary_stats = {"flood_pct": float(np.mean(result_array) * 100)}
    else:
        raise ValueError(f"No processing implemented yet for layer_type={layer_type}")

    out_key = f"eo-layers/{layer_type.value}-{uuid.uuid4()}.tif"
    raster_url = upload_bytes_to_blob(
        result_array.tobytes(), out_key, container=settings.AZURE_CONTAINER_IMAGERY
    )
    return {"raster_url": raster_url, "ai_model_id": None, "summary_stats": summary_stats}


def _synthetic_result(layer_type: LayerType) -> dict:
    """Deterministic placeholder so /api/eo/detect-change is callable in a
    local dev environment without Azure or real imagery wired up yet."""
    return {
        "raster_url": f"local-dev://synthetic/{layer_type.value}-{uuid.uuid4()}.tif",
        "ai_model_id": None,
        "summary_stats": {},
    }
