"""
Builds the actual PDF for a project report.

Kept separate from the router so the PDF layout can change without
touching the endpoint contract, and so it's easy to unit test by calling
build_report_pdf directly with a fake project/alerts list.
"""
import os
import uuid
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import mm

from app.config import settings

try:
    from app.services.storage import upload_bytes_to_blob
except ImportError:  # pragma: no cover
    upload_bytes_to_blob = None

LOCAL_REPORTS_DIR = "/tmp/urth-nexus-reports"


def build_report_pdf(project, alerts: list, period_start: datetime, period_end: datetime) -> str:
    """Returns a storage URL (Azure) or a local-dev:// path to the generated PDF."""
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleCopper", parent=styles["Title"], textColor=colors.HexColor("#c1663a"))
    heading_style = ParagraphStyle("Heading", parent=styles["Heading2"], textColor=colors.HexColor("#c1663a"))

    story = [
        Paragraph("Urth Nexus — Project Report", title_style),
        Paragraph(f"Project: {project.name}", styles["Normal"]),
        Paragraph(
            f"Period: {period_start.strftime('%Y-%m-%d')} to {period_end.strftime('%Y-%m-%d')}",
            styles["Normal"],
        ),
        Paragraph(f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}", styles["Normal"]),
        Spacer(1, 14),
        Paragraph("Alerts in this period", heading_style),
    ]

    if alerts:
        table_data = [["Triggered", "Severity", "Entity", "Message"]]
        for a in alerts:
            table_data.append([
                a.triggered_at.strftime("%Y-%m-%d %H:%M"),
                a.severity.value.upper(),
                a.entity_type,
                a.message,
            ])
        table = Table(table_data, colWidths=[80, 55, 70, 220])
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#241d16")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#ded2b8")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f1ebdd")]),
        ]))
        story.append(table)
    else:
        story.append(Paragraph("No alerts were triggered during this period.", styles["Normal"]))

    buffer_path = f"/tmp/urth-nexus-report-{uuid.uuid4()}.pdf"
    doc = SimpleDocTemplate(buffer_path, pagesize=A4)
    doc.build(story)

    with open(buffer_path, "rb") as f:
        pdf_bytes = f.read()

    if upload_bytes_to_blob and settings.AZURE_STORAGE_CONNECTION_STRING:
        blob_name = f"reports/{project.id}/{uuid.uuid4()}.pdf"
        url = upload_bytes_to_blob(pdf_bytes, blob_name, container=settings.AZURE_CONTAINER_REPORTS)
        os.remove(buffer_path)
        return url

    # Local dev fallback — keep the file where FileResponse can serve it.
    os.makedirs(LOCAL_REPORTS_DIR, exist_ok=True)
    final_path = os.path.join(LOCAL_REPORTS_DIR, os.path.basename(buffer_path))
    os.rename(buffer_path, final_path)
    return f"local-dev://{final_path}"
