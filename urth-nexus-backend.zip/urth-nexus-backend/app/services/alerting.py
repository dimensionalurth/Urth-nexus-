"""
Threshold rules that turn an EO_Layer into an Alert automatically.

Deliberately simple, explicit if/elif rules for the MVP rather than a
generic rules engine — with one layer type and a handful of thresholds,
a rules engine is solving a problem we don't have yet. Revisit once
there are enough distinct rules that hardcoding them gets unwieldy.
"""
from sqlalchemy.orm import Session

from app.models import EOLayer, LayerType, Alert, AlertSeverity, Project

# Thresholds — tune per pilot once real data exists; kept as named
# constants rather than magic numbers scattered through the function.
NDVI_CHANGE_WARNING = -0.15
NDVI_CHANGE_CRITICAL = -0.25
FLOOD_COVERAGE_WARNING_PCT = 5.0
FLOOD_COVERAGE_CRITICAL_PCT = 15.0


def check_layer_and_alert(db: Session, layer: EOLayer, project: Project, summary_stats: dict) -> Alert | None:
    """
    summary_stats is expected to carry whatever the processing step
    already computed (e.g. {'mean_change': -0.31} or {'flood_pct': 18.2}),
    so this function doesn't re-read the raster — it just applies rules.
    """
    severity = None
    message = None

    if layer.layer_type in (LayerType.ndvi, LayerType.ndvi_change):
        mean_change = summary_stats.get("mean_change")
        if mean_change is not None:
            if mean_change <= NDVI_CHANGE_CRITICAL:
                severity, message = AlertSeverity.critical, (
                    f"Significant vegetation loss detected (mean NDVI change {mean_change:.2f})"
                )
            elif mean_change <= NDVI_CHANGE_WARNING:
                severity, message = AlertSeverity.warning, (
                    f"Vegetation decline trending (mean NDVI change {mean_change:.2f})"
                )

    elif layer.layer_type == LayerType.flood_extent:
        flood_pct = summary_stats.get("flood_pct")
        if flood_pct is not None:
            if flood_pct >= FLOOD_COVERAGE_CRITICAL_PCT:
                severity, message = AlertSeverity.critical, (
                    f"Flood extent covers {flood_pct:.1f}% of the monitored area"
                )
            elif flood_pct >= FLOOD_COVERAGE_WARNING_PCT:
                severity, message = AlertSeverity.warning, (
                    f"Rising water coverage detected ({flood_pct:.1f}% of area)"
                )

    if severity is None:
        return None

    alert = Alert(
        project_id=project.id,
        entity_type="EO_Layers",
        entity_id=layer.id,
        severity=severity,
        message=message,
    )
    db.add(alert)
    db.commit()
    db.refresh(alert)
    return alert
