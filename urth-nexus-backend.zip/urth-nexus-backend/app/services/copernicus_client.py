"""
Copernicus Data Space Ecosystem (CDSE) client.

Real, verified endpoints as of the Copernicus Data Space Ecosystem docs
(https://documentation.dataspace.copernicus.eu/APIs.html):

  - Auth:     https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token
              (Keycloak password grant, public client "cdse-public" —
              your free CDSE account credentials, not a separate secret)
  - Search:   https://catalogue.dataspace.copernicus.eu/odata/v1/Products
              (OData, filterable by collection, date, cloud cover, AOI)
  - Download: https://catalogue.dataspace.copernicus.eu/odata/v1/Products({id})/$value

This client only talks to those three endpoints. It does not implement
Landsat/MODIS ingestion (those come from USGS EarthExplorer / NASA LAADS
respectively, with separate auth) — noted as future work in the README.
"""
from datetime import datetime
from typing import Optional

import httpx

from app.config import settings

TOKEN_URL = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
CATALOGUE_URL = "https://catalogue.dataspace.copernicus.eu/odata/v1/Products"
DOWNLOAD_URL_TEMPLATE = "https://catalogue.dataspace.copernicus.eu/odata/v1/Products({id})/$value"


class CopernicusAuthError(RuntimeError):
    pass


def get_access_token() -> str:
    """
    Password-grant token request against CDSE's Keycloak instance.
    Tokens are short-lived (~10 min) — callers should fetch a fresh one
    per ingestion run rather than caching long-term.
    """
    if not settings.COPERNICUS_USERNAME or not settings.COPERNICUS_PASSWORD:
        raise CopernicusAuthError(
            "COPERNICUS_USERNAME / COPERNICUS_PASSWORD not set — register a free "
            "account at https://dataspace.copernicus.eu and add credentials to .env"
        )
    resp = httpx.post(
        TOKEN_URL,
        data={
            "client_id": "cdse-public",
            "username": settings.COPERNICUS_USERNAME,
            "password": settings.COPERNICUS_PASSWORD,
            "grant_type": "password",
        },
        timeout=30,
    )
    if resp.status_code != 200:
        raise CopernicusAuthError(f"CDSE token request failed ({resp.status_code}): {resp.text}")
    return resp.json()["access_token"]


def search_sentinel2(
    bbox_wkt_polygon: str,
    date_from: datetime,
    date_to: datetime,
    max_cloud_cover_pct: float = 30.0,
    product_type: str = "S2MSI2A",  # Level-2A, atmospherically corrected — what NDVI/NDWI want
    top: int = 20,
) -> list[dict]:
    """
    Searches the CDSE catalogue for Sentinel-2 scenes intersecting the
    given area and date range. bbox_wkt_polygon must be a WKT POLYGON
    string in EPSG:4326, e.g. "POLYGON((24.7 -28.8, 24.8 -28.8, ...))".

    Returns a list of {id, name, content_date, cloud_cover, footprint}.
    """
    odata_filter = (
        f"Collection/Name eq 'SENTINEL-2' "
        f"and Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'productType' "
        f"and att/OData.CSC.StringAttribute/Value eq '{product_type}') "
        f"and OData.CSC.Intersects(area=geography'SRID=4326;{bbox_wkt_polygon}') "
        f"and ContentDate/Start gt {date_from.strftime('%Y-%m-%dT%H:%M:%S.000Z')} "
        f"and ContentDate/Start lt {date_to.strftime('%Y-%m-%dT%H:%M:%S.000Z')} "
        f"and Attributes/OData.CSC.DoubleAttribute/any(att:att/Name eq 'cloudCover' "
        f"and att/OData.CSC.DoubleAttribute/Value le {max_cloud_cover_pct})"
    )
    params = {"$filter": odata_filter, "$top": top, "$orderby": "ContentDate/Start desc"}

    resp = httpx.get(CATALOGUE_URL, params=params, timeout=60)
    resp.raise_for_status()
    results = resp.json().get("value", [])

    return [
        {
            "id": r["Id"],
            "name": r["Name"],
            "content_date": r["ContentDate"]["Start"],
            "footprint_geojson": r.get("GeoFootprint"),
        }
        for r in results
    ]


def download_product(product_id: str, access_token: str) -> bytes:
    """
    Downloads a product's zipped SAFE archive. These are large (500MB-1GB+
    for a full Sentinel-2 tile) — for the MVP this is fine at low volume,
    but production ingestion should stream to blob storage rather than
    holding the whole archive in memory. Flagged as a known scaling limit.
    """
    resp = httpx.get(
        DOWNLOAD_URL_TEMPLATE.format(id=product_id),
        headers={"Authorization": f"Bearer {access_token}"},
        timeout=600,
        follow_redirects=True,
    )
    resp.raise_for_status()
    return resp.content
