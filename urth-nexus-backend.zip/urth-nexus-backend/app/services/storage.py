"""
Thin wrapper around Azure Blob Storage — the only place blob SDK calls
happen, so imagery/report storage can move providers later without
touching routers or the processing service.
"""
from azure.storage.blob import BlobServiceClient

from app.config import settings


def _client() -> BlobServiceClient:
    return BlobServiceClient.from_connection_string(settings.AZURE_STORAGE_CONNECTION_STRING)


def upload_bytes_to_blob(data: bytes, blob_name: str, container: str) -> str:
    """Uploads raw bytes and returns the blob's URL, ready to store in
    storage_url / raster_url / file_url columns."""
    container_client = _client().get_container_client(container)
    if not container_client.exists():
        container_client.create_container()
    blob_client = container_client.get_blob_client(blob_name)
    blob_client.upload_blob(data, overwrite=True)
    return blob_client.url


def download_blob_to_memory(blob_url_or_name: str, container: str | None = None) -> bytes:
    """Downloads a blob's contents into memory. Accepts either a bare blob
    name (with `container` given) or a full blob URL."""
    if container:
        blob_client = _client().get_container_client(container).get_blob_client(blob_url_or_name)
    else:
        blob_client = _client().get_blob_client(container=None, blob=blob_url_or_name)  # type: ignore[arg-type]
    return blob_client.download_blob().readall()
