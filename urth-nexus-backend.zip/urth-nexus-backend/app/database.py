"""
SQLAlchemy engine + session management.

One synchronous engine is enough at MVP scale — FastAPI handles the
Depends-per-request session pattern fine without going async here.
Move to async SQLAlchemy only if request volume actually demands it.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

from app.config import settings

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine, future=True)

Base = declarative_base()


def get_db():
    """FastAPI dependency — yields a DB session and always closes it."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_postgis(engine_):
    """
    Ensures the PostGIS extension exists. Run once against a fresh database
    (Azure Database for PostgreSQL Flexible Server has PostGIS available as
    an allow-listed extension — enable it in the Azure portal first, then
    this CREATE EXTENSION call will succeed).
    """
    with engine_.connect() as conn:
        conn.exec_driver_sql("CREATE EXTENSION IF NOT EXISTS postgis;")
        conn.commit()
