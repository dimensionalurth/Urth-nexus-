"""
Urth Nexus API — single deployable FastAPI application.

Every capability (auth, imagery, layers, eo, alerts, reports) is a router
module inside this one app, not a separate service — see the "Why a
monolith" note in the technical spec. Split any of these into its own
service later only once real load demands independent scaling.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.routers import auth, imagery, layers, eo, alerts, reports

app = FastAPI(
    title="Urth Nexus API",
    description="Earth Observation, AI and GIS decision-support platform — MVP backend.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(imagery.router)
app.include_router(layers.router)
app.include_router(eo.router)
app.include_router(alerts.router)
app.include_router(reports.router)


@app.get("/api/health", tags=["health"])
def health_check():
    return {"status": "ok", "environment": settings.ENVIRONMENT}
