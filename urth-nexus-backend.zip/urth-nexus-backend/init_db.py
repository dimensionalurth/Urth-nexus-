"""
Creates the PostGIS extension and all 13 tables.

Run once against a fresh database:
    python init_db.py

For anything beyond local dev, replace this with Alembic migrations —
this script is intentionally the fast path to get a working MVP database,
not a long-term migration strategy.
"""
from sqlalchemy import text

from app.database import engine, Base
from app import models  # noqa: F401 — import registers all model classes with Base


def main():
    with engine.connect() as conn:
        conn.execute(text("CREATE EXTENSION IF NOT EXISTS postgis"))
        conn.commit()
    Base.metadata.create_all(bind=engine)
    print("✓ PostGIS extension enabled")
    print("✓ All tables created:")
    for table in Base.metadata.sorted_tables:
        print(f"   - {table.name}")


if __name__ == "__main__":
    main()
