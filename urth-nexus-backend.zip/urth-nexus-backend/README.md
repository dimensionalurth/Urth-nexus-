# Urth Nexus™ — Backend (MVP)

FastAPI + PostgreSQL/PostGIS backend for the Urth Nexus Earth Observation
platform. Built as a single deployable service (a "modular monolith") —
see the architecture note below before reaching for microservices.

## Stack

| Layer | Technology |
|---|---|
| API | Python + FastAPI |
| Database | PostgreSQL + PostGIS |
| AI / ML | PyTorch, TensorFlow, scikit-learn |
| GIS | GDAL, Rasterio, GeoPandas |
| Cloud | Microsoft Azure (Blob Storage, App Service / Container Apps) |
| Satellite data | Copernicus Sentinel, Landsat, MODIS |
| Weather | SAWS where available, Open-Meteo as fallback |

## Project layout

```
app/
  main.py              FastAPI app, wires up all routers
  config.py            Settings loaded from .env
  database.py           SQLAlchemy engine/session setup
  models.py             All 13 tables (SQLAlchemy + GeoAlchemy2)
  schemas.py             Pydantic request/response models
  deps.py                 Shared auth dependency
  routers/
    auth.py               Register / login (JWT)
    imagery.py             MVP #1 — list satellite imagery
    layers.py               MVP #2 — municipal boundary & infrastructure GeoJSON
    eo.py                     MVP #3 — vegetation change / flood detection
    alerts.py                  MVP #4 — alert CRUD
    reports.py                   MVP #5 — PDF report generation & download
  services/
    eo_processing.py    NDVI / flood-extent raster math (rasterio, numpy)
    alerting.py           Threshold rules that turn EO layers into alerts
    report_builder.py      Builds the actual PDF (reportlab)
    storage.py               Azure Blob Storage helper
init_db.py             Creates PostGIS extension + all tables
docker-compose.yml     PostGIS + API for local dev
Dockerfile
requirements.txt
.env.example
```

## Local development

1. Copy environment config:
   ```bash
   cp .env.example .env
   ```
   Leave `AZURE_STORAGE_CONNECTION_STRING` blank to run fully local — the
   EO processing and report generation both fall back to local disk /
   synthetic results when Azure isn't configured, so the API is fully
   exercisable without cloud credentials.

2. Start PostGIS + API:
   ```bash
   docker compose up --build
   ```

3. Create the schema (first run only):
   ```bash
   docker compose exec api python init_db.py
   ```

4. API is now live at `http://localhost:8000`. Interactive docs at
   `http://localhost:8000/docs`.

### Running without Docker

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
# requires a local PostGIS instance matching DATABASE_URL in .env
python init_db.py
uvicorn app.main:app --reload
```

Note: `rasterio` and `GDAL` need system GDAL libraries. On macOS,
`brew install gdal` first; on Ubuntu/Debian, `apt install gdal-bin
libgdal-dev` (already handled inside the Dockerfile).

## The five MVP endpoints

| Capability | Endpoint |
|---|---|
| Display satellite imagery | `GET /api/imagery?aoi=&date_from=&date_to=&source=` |
| Municipal boundaries & infrastructure | `GET /api/layers/municipalities`, `GET /api/layers/infrastructure` |
| Vegetation change / flood detection | `POST /api/eo/detect-change` |
| Alerts | `GET /api/alerts`, `POST /api/alerts`, `PATCH /api/alerts/{id}/acknowledge` |
| Reports | `POST /api/reports/generate`, `GET /api/reports/{id}/download` |

All routes except `/api/auth/*` and `/api/health` require a Bearer token
from `POST /api/auth/login`.

## Architecture note — why one service, not six

The original platform sketch proposed separate API Gateway, Auth, AI
Engine and GIS Engine services. This backend implements the same
separation of concerns as FastAPI routers and service modules inside one
deployable app instead. That gets a working pilot backend live in weeks,
not months, on one Azure App Service instance instead of six. Split any
module into its own service later — only once real load on that specific
module demands independent scaling.

## Sentinel-2 ingestion job

Pulls new imagery from the Copernicus Data Space Ecosystem (CDSE) for
every active Project's AOI and writes it into `satellite_images`.

```bash
# Register a free account first: https://dataspace.copernicus.eu
# Add COPERNICUS_USERNAME / COPERNICUS_PASSWORD to .env

docker compose exec api python -m app.jobs.ingest_sentinel
```

What it does, in order:
1. Fetches an access token from CDSE's Keycloak endpoint (password grant,
   tokens are short-lived — fetched fresh per run, not cached).
2. For each active Project, builds a bounding-box search from `aoi_geom`
   and queries the CDSE catalogue for Sentinel-2 L2A scenes from the last
   10 days with ≤30% cloud cover.
3. Skips any scene whose CDSE product id is already present in
   `satellite_images` (dedup check on `storage_url`).
4. Downloads new scenes, uploads to Azure Blob (`satellite-imagery`
   container) or falls back to `/tmp/urth-nexus-imagery` locally, and
   inserts the `SatelliteImage` row.

**Scheduling it:** this is a plain script, not wired into the FastAPI
process — ingestion involves large, slow downloads that shouldn't share
an event loop with API requests. Two straightforward options:
- **Cron** (simplest): `0 3 * * * docker compose exec -T api python -m app.jobs.ingest_sentinel`
- **Azure Container Apps Jobs**: package the same Dockerfile as a
  scheduled job triggered independently of the API's App Service —
  no separate infrastructure to stand up.

**Known scaling limit, flagged honestly:** full Sentinel-2 SAFE archives
run 500MB–1GB+. `download_product()` currently holds the whole archive in
memory before uploading to blob. Fine at pilot volume (a handful of
scenes/day for one or two AOIs); worth switching to a streaming
download→upload before running this across many concurrent projects.

## What's stubbed vs real

- **Real and runnable today:** all 5 MVP endpoints, JWT auth, PostGIS
  spatial queries, NDVI/NDWI raster math, PDF report generation, and the
  Sentinel-2 ingestion job above (real CDSE endpoints, not mocked).
- **Stubbed pending credentials/agreements:** SAWS integration (needs a
  data-sharing agreement — Open-Meteo covers the gap), Azure Blob Storage
  (needs a connection string — falls back to local disk without one).
- **Not yet built:** Landsat and MODIS ingestion (separate APIs — USGS
  EarthExplorer and NASA LAADS respectively, each with their own auth;
  the spec lists them but Sentinel-2 via CDSE covers the MVP milestone
  on its own).

## Next steps

1. `docker compose up` and confirm `/api/health` responds.
2. Register a test user, create an Organization + Project via the API
   (or a short seed script) so `/api/eo/detect-change` and
   `/api/reports/generate` have real foreign keys to work against.
3. Wire the Flutter dashboard's HTTP client to these endpoints in place
   of the simulated data in the current prototype.
4. Build the Copernicus ingestion job (Phase 1 of the sequencing plan).
